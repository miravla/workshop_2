package com.example.UtemSmartParkingApplication.ESP32Connection;

public class ESP32Connection {
}
