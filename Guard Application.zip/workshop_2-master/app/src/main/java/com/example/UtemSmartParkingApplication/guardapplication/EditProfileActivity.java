package com.example.UtemSmartParkingApplication.guardapplication;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.UtemSmartParkingApplication.R;

public class EditProfileActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState1) {
        super.onCreate(savedInstanceState1);
        setContentView(R.layout.edit_profile);
    }
}